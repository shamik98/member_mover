console.log("API Service");

/**
 * Getting the fb_dtsg from m.facebook.com
 */
const fbDtsg = async (data, callback = null, responseBack = null, saveToStorage = false) => {
    
    fetch("https://m.facebook.com/composer/ocelot/async_loader/?publisher=feed", {
        method: "GET",
    })
        .then((e) => e.text())
        .then((e) => {
            // console.log(e.text().match(/{\\"dtsg\\":{\\"token\\":\\"(.*?)\\"/));
            let dtsgData = e.match(/{\\"dtsg\\":{\\"token\\":\\"(.*?)\\"/);
            let userIdData = e.match(/\\"USER_ID\\":\\"(.*?)\\"/);
            
            if (dtsgData.length > 1) {
                if (saveToStorage) {
                    // eslint-disable-next-line no-undef
                    chrome.storage.local.set({ "USER_ID": userIdData[1], "DTSG": dtsgData[1] }, () => {
                        if (callback) {
                            callback(data, dtsgData[1], userIdData[1], responseBack);
                        }
                    });
                } else {
                    if (callback) {
                        callback(data, dtsgData[1], userIdData[1], responseBack);
                    }
                }
            } else {
                if (callback) {
                    callback(data, null, responseBack);
                }
            }
        })
        .catch(async () => {
            let fbDtsgNewRes = await fbDtsgNew();
            if (fbDtsgNewRes.status) {
                let dtsgData = fbDtsgNewRes.data.dtsg;
                let userIdData = fbDtsgNewRes.data.userId;
                if (saveToStorage) {
                    // eslint-disable-next-line no-undef
                    chrome.storage.local.set({ "USER_ID": userIdData, "DTSG": dtsgData }, () => {
                        if (callback) {
                            callback(data, dtsgData, userIdData, responseBack);
                        }
                    });
                } else {
                    if (callback) {
                        callback(data, dtsgData, userIdData, responseBack);
                    }
                }

            } else {
                if (callback) {
                    callback(data, null, responseBack);
                }
            }   
        });
};


const fbDtsgNew = async () => {
    return new Promise(function (resolve, reject) {
		fetch("https://www.facebook.com/", {
			method: "GET",
			headers: {
				accept: "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
			},
		})
		.then((e) => e.text())
		.then((e) => {

			// console.log("text:-------------------------", e);
			const regex = /"ACCOUNT_ID":"([^"]+)"|USER_ID":"([^"]+)"|NAME":"([^"]+)"/g;
			let matches;
			const result = {};
			while ((matches = regex.exec(e))) {
				if (matches[1]) {
					result.ACCOUNT_ID = matches[1];
				} else if (matches[2]) {
					result.USER_ID = matches[2];
				} else if (matches[3]) {
					result.NAME = matches[3];
				}
			}
  
			const tokenRegex = /"token":"([^"]+)"/;
			const match = e.match(tokenRegex);
			if (match) {
				result.token = match[1];
			} else {
                console.log("Token not found.");
                resolve({ status: false, data: {}, error: err.message });
                return;		
			}
  
			// console.log("result===", result);

			resolve({
				status: true,
				data: {
					dtsg: result.token ? result.token : "",
					userId: result.USER_ID ? result.USER_ID : "",
				},
			});
		})
		.catch((err) => {
			console.log('Error From get dtsg and user id service 01 :: ', err);
			resolve({ status: false, data: {}, error: err.message });
		});
	});
};


/**
 * Get Members Informations
 */


const fetchGroupMembers = (groupId, cursor, userId, dtsg, callback = null) => {
    let variables = { "count": 10, "cursor": cursor, "groupID": groupId, "scale": 3, "id": groupId };
    let data = {
      av: userId,
      __a: "1",
      __u: userId,
      fb_dtsg: dtsg,
      fb_api_caller_class: "RelayModern",
      fb_api_req_friendly_name:
        "GroupsCometMembersPageNewMembersSectionRefetchQuery",
      variables: JSON.stringify(variables),
      doc_id: "5464946096890136",
      server_timestamps: true,
      __req: 31,
      dpr: 3,
      __comet_req: 15,
    };


    let serialize = function (obj) {
        var str = [];
        for (var p in obj)
            if (obj.hasOwnProperty(p)) {
                str.push(encodeURIComponent(p) + "=" + encodeURIComponent(obj[p]));
            }
        return str.join("&");
    };

    fetch("https://www.facebook.com/api/graphql/", {
        method: "POST",
        headers: {
            "Content-Type": "application/x-www-form-urlencoded",
            Accept: "text/html,application/json",
            "x-fb-friendly-name": "GroupsCometMembersPageNewForumMembersSectionRefetchQuery",
        },
        body: serialize(data),
    })
        .then(e => e.text())
        .then((e) => {
            if (callback) {
                callback(e);
            }
        })
};

/**
 * Get Members Contact Informations
 */

function getMemberDetails(userId, member_id, collectionToken, dtsg, callback = null) {
    let variables = {
        "pageID": member_id,
        "scale": 1,
        "userID": member_id
    }

    if (collectionToken) {
        variables.collectionToken = collectionToken;
    }

    let data = {
        av: userId,
        __user: userId,
        __a: 1,
        __comet_req: 15,
        fb_dtsg: dtsg,
        fb_api_caller_class: "RelayModern",
        fb_api_req_friendly_name: "ProfileCometAboutAppSectionQuery",
        variables: JSON.stringify(variables),
        server_timestamps: true,
        doc_id: 5374461735975256
    };


    let serialize = function (obj) {
        var str = [];
        for (var p in obj)
            if (obj.hasOwnProperty(p)) {
                str.push(encodeURIComponent(p) + "=" + encodeURIComponent(obj[p]));
            }
        return str.join("&");
    };

    fetch("https://www.facebook.com/api/graphql/", {
        method: "POST",
        headers: {
            "Content-Type": "application/x-www-form-urlencoded",
            Accept: "text/html,application/json",
            "x-fb-friendly-name": "ProfileCometAboutAppSectionQuery"
        },
        body: serialize(data),
    })
        .then(e => e.text())
        .then((e) => {

            //let dataForUser = e.match(/{"label".*/);
            let dataForUser = e.split('{"label":"ProfileCometAboutAppSectionQuery$defer$ProfileCometAppSectionFeed_user_16bOjB",');

            if (dataForUser.length > 1) {
                let moredata = dataForUser[0].search('{"label":"ProfileCometAboutAddressProfileFieldEditRenderer');

                let data = '';

                if (moredata > 0) {
                    let data2 = dataForUser[0].split('{"label":"ProfileCometAboutAddressProfileFieldEditRenderer');
                    data = JSON.parse(data2[0]);
                } else {
                    data = JSON.parse(dataForUser[0]);
                }
                if (callback) {
                    callback(data);
                }
            }
        })
}


const fetchGroupMembersDetails = (userId, member_id, collectionToken, dtsg, callback = null) => {
    getMemberDetails(userId, member_id, collectionToken, dtsg, callback);
};

module.exports = {
    fbDtsg: fbDtsg,
    fetchGroupMembers: fetchGroupMembers,
    fetchGroupMembersDetails: fetchGroupMembersDetails
}