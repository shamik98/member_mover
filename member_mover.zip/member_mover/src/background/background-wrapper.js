try {
  importScripts('js/background.bundle.js');
} catch (error) {
  console.log(error);
}
