var config = require('../config/config.js');
var settings = require('../../public/kyubiSettings.json');
import apiServices from '../services/apiServices.js';

// const { io } = require('socket.io-client');

console.log("Working......");

var facebook = /^(http|https):\/\/(www.)*(facebook)(\.com)\/groups/;

var debugger_mode = true;
let debug_mode = false; // new added
let get_member_open_tab = true;

var all_member_details = [];
var membersInfo = [];
var close_after_save = [];

var exportMembersCount = 1;

const cr = chrome.runtime,
	cs = chrome.storage.local,
	ci = chrome.identity,
	ct = chrome.tabs,
	ca = chrome.action,
	cal = chrome.alarms;

cs.set({ membersData: membersInfo });

ct.onActivated.addListener(function (activeInfo) {
	chrome.storage.local.set({ all_member_details: all_member_details });
	// console.log("onAction icon clicked.")
	setPopup();
});

ct.onUpdated.addListener(function (activeInfo) {
	// console.log("onUpdate icon clicked. :: ");
	setPopup();
});

function setPopup() {
	chrome.storage.local.get(['store'], function (res) {
		cs.get(['popupState'], function (result) {
			if (res.store !== undefined && res.store.user.email !== undefined && res.store.user.email && result.popupState === undefined) {
				ca.setPopup({ popup: '../dashboard.html' });
			} else {
				switch (result.popupState) {
					case "dashboard":
						ca.setPopup({ popup: '../dashboard.html' });
						break;
					case "processing":
						//ca.setPopup({ popup: '../processingData.html' });
						ca.setPopup({ popup: '../dashboard.html' });
						// document.getElementById("downloadSystem").style.display = "block";
						// document.getElementsByClassName("modalcontent downloadProcess").style.display = "block";
						// document.getElementsByClassName("modalcontent downloadSuccess").style.display = "none";
						break;
					case "Complete":
						//ca.setPopup({ popup: '../Congratulations.html' });
						ca.setPopup({ popup: '../dashboard.html' });
						// document.getElementById("downloadSystem").style.display = "block";
						// document.getElementsByClassName("modalcontent downloadProcess").style.display = "none";
						// document.getElementsByClassName("modalcontent downloadSuccess").style.display = "block";
						break;
					default:
						ca.setPopup({ popup: '../popup.html' });
						break;
				}
			}
		});
	});
};

cr.onInstalled.addListener(function (details) {
	if (details.reason == 'install') {
		//call a function to handle a first install
		if (settings.installedURL) ct.create({ url: settings.installedURL });
	} else if (details.reason == 'update') {
		//call a function to handle an update
	}
});
/**
 * @desc Open URL after uninstall the extension
 */
if (settings.uninstalledURL) {
	cr.setUninstallURL(settings.uninstalledURL, function () {
		var lastError = cr.lastError;
		if (lastError && lastError.message) {
			console.warn('Unable to set uninstall URL: ' + lastError.message);
		}
	});
}

cal.onAlarm.addListener(async function (alarm) {
	if (alarm.name.startsWith("gmcrm-get-fbDtsg")) {
		apiServices.fbDtsg(null, null, null, true);
	}
});

const alarmCreateForInterval = (name, time) => {
	chrome.alarms.get(name, (alarm) => {
		if (alarm) {
			console.log('-');
		} else {
			console.log('- not there');
			chrome.alarms.create(name, {
				periodInMinutes: time,
				delayInMinutes: time,
			});
		}
	});
}

chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
	if (message.msg == 'get_tab_id') {
		if (sender.url.indexOf("groups") == -1) {
			chrome.storage.local.set({ firstTabId: sender.tab.id });
			chrome.tabs.sendMessage(sender.tab.id, { sender_tab_id: sender.tab.id }, function (response) { });
		} else {
			chrome.storage.local.set({ homeTabId: sender.tab.id });
		}
	}

	if (message.message == 'fetch_member') {
		chrome.storage.local.get('homeTabId', function (tabId) {
			chrome.tabs.sendMessage(tabId.homeTabId, {
				message: "getMemberDetails",
				delayInterval: message.delayInterval,
				USER_ID: message.USER_ID,
				DTSG: message.DTSG,
				members: message.members,
				memberPageInfo: message.memberPageInfo,
				positive_keywords: message.positive_keywords,
				negative_keywords: message.negative_keywords,
			}, function (response) { });
		})
	}

	if (message.message == 'receive_from_page') {
		membersInfo.push(message.update_msg[0]);

		chrome.storage.local.get('membersData', function (result) {
			exportMembersCount = 1;
			if (message.update_msg[0] && message.update_msg[0] !== undefined) {
				result.membersData.push(message.update_msg[0]);
			}
			cs.set({ membersData: result.membersData });
			ca.setBadgeText({ text: result.membersData.length.toString() });
			ca.setBadgeBackgroundColor({ color: '#f14336' });
			chrome.runtime.sendMessage({ type: "setCount", count: result.membersData.length });
			cs.set({ newTabId: message.sender_id });
			if (message.close_after_save !== undefined && message.close_after_save) {
				close_after_save.push(message.close_after_save);
			}
		})
	}

	if (message.message == 'retriveTheDataFromLocalStorage' || message.message == 'exportMembers') {
		chrome.storage.local.get('homeTabId', function (tabId) {
			// console.log("tabId =================================== ", tabId)
			ca.setBadgeBackgroundColor({ color: '#f14336' })
			ca.setBadgeText({ text: 'Done' });
			chrome.runtime.sendMessage({ msg: "reload" });
			chrome.storage.local.get('newTabId', function (newTabId) {
				// console.log("newTabId ==========================", newTabId)
				chrome.tabs.remove(newTabId.newTabId)
			})
			chrome.storage.local.get('membersData', function (result) {
				// console.log("membersData --------------------------", result)
				if ((exportMembersCount == 1 && message.message == 'exportMembers') || message.message == 'retriveTheDataFromLocalStorage') {
					chrome.storage.local.remove(["newTabId"], function () {
						var error = chrome.runtime.lastError;
						if (error) {
							console.error("error inside if ->", error);
						}
					})
					// console.log("callFunction calling--------------------------", result.membersData);
					chrome.tabs.sendMessage(tabId.homeTabId, { message: "callFunction", data: result.membersData }, function (response) { });
					cs.set({ membersData: [] });
					chrome.storage.local.set({ all_member_details: all_member_details });
					cs.set({ newTabId: null });
					exportMembersCount++;
				}
			})
		})
	}

	if (message.msg == "Complete") {
		cs.set({ popupState: "Complete" });
		ca.setBadgeBackgroundColor({ color: "#f14336" });
		ca.setBadgeText({ text: "Done" });
		setPopup();
	}

	if (message.msg == "processing") {
		cs.set({ popupState: "processing" });
		setPopup();
	}

	if (message.msg == "clearBadge") {
		ca.setBadgeText({ text: "" });
	}

	if (message.msg == "reload") {
		cs.set({ popupState: "dashboard" });
		setPopup();
	}

	if (message.msg == "open_tab" && get_member_open_tab) {
		if (membersInfo.length == 0) {
			cs.set({ newTabId: null });
		}
		chrome.storage.local.set({ TotalCount: message.TotalCount });
		openTab(
			message.member_info,
			message.USER_ID,
			message.DTSG,
			message.member_details_length,
			message.member_details_page_info,
			message.count,
			message.desc
		);
	}

	if (message.msg == "set_count") {
		ca.setBadgeBackgroundColor({ color: '#f14336' });
		ca.setBadgeText({ text: message.count.toString() });
		chrome.runtime.sendMessage({ type: "setCount", count: message.count });
	}
});

// codes for keep service worker active.
setInterval(function () {
	chrome.runtime.sendMessage({ type: 'wake-up' });
}, 10000);

self.addEventListener('message', (event) => {
	if (event.data && event.data.type === 'wake-up') {
		console.log("awake");
	}
});


alarmCreateForInterval("activeServiceWorker", 1);

function openTab(member_info, USER_ID, DTSG, member_details_length, member_details_page_info, count, desc) {
	let pageUrl = "https://www.facebook.com/profile.php?id=" + member_info.fb_id + "&sk=about_contact_and_basic_info";

	chrome.storage.local.get('newTabId', function (newTabId) {
		if (newTabId.newTabId !== undefined && newTabId.newTabId) {
			chrome.tabs.update(newTabId.newTabId, { url: pageUrl, active: false, pinned: true }, function (tab) {
				let member_details = { 'member_info': member_info, 'USER_ID': USER_ID, 'DTSG': DTSG, 'member_details_length': member_details_length, 'member_details_page_info': member_details_page_info, 'count': count, 'desc': desc };

				chrome.storage.local.set({ all_member_details: member_details });
			});
		} else {
			chrome.tabs.create({ url: pageUrl, active: false }, function (newTab) {
				chrome.tabs.update(newTab.id, { active: false, pinned: true });
				let member_details = { 'member_info': member_info, 'USER_ID': USER_ID, 'DTSG': DTSG, 'member_details_length': member_details_length, 'member_details_page_info': member_details_page_info, 'count': count, 'desc': desc };

				chrome.storage.local.set({ all_member_details: member_details });
			});
		}
	})
}

/** -------------------Code	 for kyubi Broadcast feature---------------- */


function urlBase64ToUint8Array(base64String) {
	const padding = '='.repeat((4 - (base64String.length % 4)) % 4);
	const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');

	const rawData = window.atob(base64);
	const outputArray = new Uint8Array(rawData.length);

	for (let i = 0; i < rawData.length; ++i) {
		outputArray[i] = rawData.charCodeAt(i);
	}
	return outputArray;
}

// Register the service worker
// Register Push
// Send the push

const sendFn = async () => {
	// Register SErvice Worker
	// console.log('Registering service worker');
	const register = await navigator.serviceWorker.register('./worker.js', {
		scope: '/',
	});

	// console.log('waiting for ready : ', register);
	await navigator.serviceWorker.ready;
	// console.log('register service worker : ', register);
	// console.log(
	//   'Public Vapid key',
	//   urlBase64ToUint8Array(settings.publicVapidKey)
	// );
	const subscription = await register.pushManager.subscribe({
		userVisibleOnly: true,
		applicationServerKey: urlBase64ToUint8Array(settings.publicVapidKey),
	});
	// console.log('Push registered..', subscription);

	chrome.storage.local.set(
		{
			subscription: JSON.parse(JSON.stringify(subscription)),
		},
		function (setData) {
			// console.log('setted');
		}
	);

	chrome.storage.local.get(['subscription'], function (storageData) {
		// console.log('broadcast subscription object', storageData.subscription);
	});
};

cal.create("get-fbDtsg", {
	when: new Date().getTime(),
	periodInMinutes: 5
});

apiServices.fbDtsg(null, null, null, true);