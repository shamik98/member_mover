var kyubiSettings = require('../../public/kyubiSettings.json');
const env = 'stage';

module.exports = {

	mmData: {
		user: 'user',
		level: 'level',
		sheetURL: 'sheetURL',
		membersToRemove: 'membersToRemove',
		allGroupDetails: 'allGroupDetails',
		portalTabId: 'portalTabId',
		allAutomations: 'allAutomations',
		allPostsDetails: 'allPostsDetails',
		allComments: 'allComments',
		allReactions: 'allReactions',
		engagementInfo: 'engagementInfo',
	},

	googleAPIkey: 'AIzaSyAAd9XAvjlbjhKC6FHvjz7ejvOmenbZpVY',

	getKyubiPlan: 'https://app.kyubi.io/api/end-user/get-plan',
	genderAPIprod:
		'https://z7c5j0fjy8.execute-api.us-east-2.amazonaws.com/prod/genderapi',
	genderAPIdev:
		'https://z7c5j0fjy8.execute-api.us-east-2.amazonaws.com/dev/genderapi',

	genderLamdaApi: kyubiSettings.lamdaApiLink,

	getUserDataFromStorage: function (data) {
		return new Promise((resolve) => {
			try {
				chrome.storage.local.get(data, async (i) => {
					let loggedIN = i.level || '';
					resolve(loggedIN);
				});
			} catch (e) {
				resolve({});
			}
		});
	},

	getGroupDataFromStorage: function (data) {
		return new Promise((resolve) => {
			try {
				chrome.storage.local.get(data, async (i) => {
					let groupData = i.allGroupDetails || '';
					resolve(groupData);
				});
			} catch (e) {
				resolve({});
			}
		});
	},

	getAuthTokenForUser: function () {
		return new Promise((resolve) => {
			try {
				chrome.identity.getAuthToken(
					{
						interactive: true,
					},
					function (token) {
						if (token) resolve(token);
						else resolve(null);
					}
				);
			} catch (e) {
				resolve(null);
			}
		});
	},

	toastMessage: function (message, status) {
		toastr.options = {
			closeButton: true,
			debug: false,
			newestOnTop: false,
			progressBar: true,
			preventDuplicates: true,
			onclick: null,
			showDuration: '300',
			hideDuration: '1000',
			timeOut: '3000',
			extendedTimeOut: '1000',
			showEasing: 'swing',
			hideEasing: 'linear',
			showMethod: 'show',
			hideMethod: 'hide',
		};

		switch (status) {
			case 'success':
				toastr.success(message);
				break;
			case 'error':
				toastr.error(message);
				break;
			case 'info':
				toastr.info(message);
				break;
			default:
				return false;
		}
	},
};
