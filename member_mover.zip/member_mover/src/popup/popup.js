var config = require('../config/config.js');
var settings = require('../../public/kyubiSettings.json');



const cr = chrome.runtime,
  cs = chrome.storage.local,
  ci = chrome.identity,
  ct = chrome.tabs,
	cb = chrome.browserAction;

/**
 *
 * @param {String} email
 * @param {String} password
 * @desc Check password and email are valid or not
 */
async function checkEmail(
  email,
  password,
  confirmLogout = false,
  subscription
) {
  try {
    var extra = '';
    if (typeof password != undefined && password.trim() != '') {
      extra = '&password=' + password;
    }

    let res = await fetch(settings.loginURL, {
      method: 'POST',
      mode: 'cors',
      cache: 'no-cache',
      headers: {
        'Content-Type': 'application/json',
      },
      redirect: 'follow',
      referrerPolicy: 'no-referrer',
      body: JSON.stringify({
        email: email,
        password: password,
        extensionId: settings.extId,
        deviceId: getDeviceId(),
        confirmLogout: confirmLogout,
        subscription: subscription,
      }),
    });

    let jsonRes = res.json();
    return jsonRes;
  } catch (error) {
    alert(error.message);
    return false;
  }
}

async function checkAndSaveEmail(email, password, logout, subscription) {
  const info = await checkEmail(email, password, logout, subscription);
  if (info.status && info.token) {
    let infoPlan = await getUserPlan(email);
    if (infoPlan.status) {
        cs.set({
          level: {
            valid: true,
            mmAuthToken: info.token,
            mmUsrEmail: email,
            planNo: info.plan,
            planName: infoPlan.payload.plan_details.name,
          },
        });

        let store = {
          user: {
            email: email,
            token: info.token
          }
        }

        chrome.storage.local.set({store: store}, function () {
          chrome.storage.local.get(['store'], function (res) {  
            chrome.storage.local.get(['popupState'], function (result) {
              switch ( result.popupState ) {
                case "dashboard":
                    window.location.href='../dashboard.html' ;
                    break;
                case "processing":
                    //window.location.href='../processingData.html' ;
                    window.location.href='../dashboard.html' ;
                    $("#downloadSystem").show();
                    $(".modalcontent.downloadProcess").show();
                    $(".modalcontent.downloadSuccess").hide();
                    break;
                case "Complete":
                    //window.location.href='../Congratulations.html' ;
                    window.location.href='../dashboard.html' ;
                    $("#downloadSystem").show();
                    $(".modalcontent.downloadProcess").hide();
                    $(".modalcontent.downloadSuccess").show();
                    break;
                default:
                    window.location.href='../dashboard.html' ;
                    break;
              }
            });
          });
      });

      cr.sendMessage({ date: { loggedIN: true }, type: 'successLogin' });
    } else {
      $('.login-btn').text('Login');
      return false;
    }
  } else if (info.status && !info.token) {
    const ConfirmMsg = confirm(info.message);
    if (ConfirmMsg == true) {
      checkAndSaveEmail(email, password, true, subscription);
    } else {
      $('.login-btn').text('Login');
      return false;
    }
  } else {
    $('.login-btn').text('Login');
    //$('.form-error-message').text(info.message).show();
    alert(info.message);
    cs.set({
      level: {
        valid: false,
        mmAuthToken: '',
        mmUsrEmail: ''
      },
    });
    // console.log('login failed', info);
    // alert(info.message);
    $('.login-btn').text('Login');
    return false;
  }
}

async function getUserPlan(email) {
  try {
    let res = await fetch(config.getKyubiPlan, {
      method: 'POST',
      mode: 'cors',
      cache: 'no-cache',
      headers: {
        'Content-Type': 'application/json',
      },
      redirect: 'follow',
      referrerPolicy: 'no-referrer',
      body: JSON.stringify({
        email: email,
        extnsion_id: settings.extId,
      }),
    });

    let jsonRes = res.json();

    return jsonRes;
  } catch (error) {
    alert(error.message);
    return false;
  }
}


/**
 *
 * @param {String} email
 * @desc Forget password functionality
 */
async function forgotPass(email) {
  try {
    let res = await fetch(settings.forgotPassURL, {
      method: 'POST',
      mode: 'cors',
      cache: 'no-cache',
      headers: {
        'Content-Type': 'application/json',
      },
      redirect: 'follow',
      referrerPolicy: 'no-referrer',
      body: JSON.stringify({ extId: settings.extId, email: email }),
    });

    let jsonRes = res.json();
    return jsonRes;
  } catch (error) {
    alert(error.message);
    return false;
  }
}

/** Generate Devide ID */

const getDeviceId = () => {
  var navigator_info = window.navigator;
  var screen_info = window.screen;
  var uid = navigator_info.mimeTypes.length;
  uid += navigator_info.userAgent.replace(/\D+/g, '');
  uid += navigator_info.plugins.length;
  uid += screen_info.height || '';
  uid += screen_info.width || '';
  uid += screen_info.pixelDepth || '';

  return uid;
};

if ($('.login-btn').length > 0) {
  $('.login-btn').click(function () {
    var email = $('#email').val();
    var password = $('#password').val();
    var emailReg =
      /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

    if (!email || !emailReg.test(email)) {
      //$('.form-error-message').show();
      alert("Please enter a valid email");
    } else if (password == ""){
      alert("Password cannot be blank");
    } else {
      $('.login-btn').text('Logging in...');
      chrome.storage.local.get('subscription', async function (res) {
        checkAndSaveEmail(email, password, false, res.subscription);
      });
    }
  });
}

if ($('.forgotPass-btn').length > 0) {
  $('.forgotPass-btn').click(async function () {
    var email = $('#emailForgot').val();
    var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
    $('.form-error-message').hide();
    if (!email || !emailReg.test(email)) {
      $('.form-error-message').show();
    } else {
      let info = await forgotPass(email);
      if (info.status) {
        // location.href = "popup.html";
        $('.form-success-message').text(info.message).show();
      } else {
        $('.form-error-message').text(info.message).show();
      }
    }
  });
}

$('input').on('change keyup paste click', function () {
  $('.form-error-message').hide();
  $('.form-success-message').hide();
});

$('.backBtn').click(() => {
  location.href = './dashboard.html';
});
