const kyubiConfig = require('../../public/kyubiSettings.json');
const config = require('../config/config.js');

$(document).ready(async function () {

	let loggedIN = await config.getUserDataFromStorage(config.mmData.level);
	if (loggedIN.valid) {
		if (kyubiConfig.logo.secondary_logo) {
			$('.logo').attr('src', kyubiConfig.logo.secondary_logo);
		}
		$('.cancelAccountEmail').text(kyubiConfig.mailTo);
	} else {
		if (kyubiConfig.logo.primary_logo) {
      $(".logosection").addClass("loggedOut");
      $(".midContent").addClass("loginPage");
			$('.logo').attr('src', kyubiConfig.logo.primary_logo);
		}
		$('.cancelAccountEmail').text(kyubiConfig.mailTo);
	}
	

	if (kyubiConfig.footer.showFooter) {
		var poweredByHtml = '';
		if (kyubiConfig.footer.poweredBy.willBeDisplayed) {
			if (kyubiConfig.footer.poweredBy.label) {
				poweredByHtml += `Powered By <a href="${kyubiConfig.footer.poweredBy.url}" target="_blank">${kyubiConfig.footer.poweredBy.label}</a>`;
			}
		}

		if (kyubiConfig.footer.partnership.willBeDisplayed) {
			if (kyubiConfig.footer.partnership.label) {
				poweredByHtml += ` and <a href="${kyubiConfig.footer.partnership.url}" target="_blank">${kyubiConfig.footer.partnership.label}</a>`;
			}
		}

		$('#powerText').html(poweredByHtml);

		var chatSupportHtml = '';
		if (kyubiConfig.footer.chatSupport.willBeDisplayed) {
			if (kyubiConfig.footer.chatSupport.label) {
				// $('.chatSpprt').html(
				// 	`<img src="images/Messenger.svg" alt="messenger" /> ${kyubiConfig.footer.chatSupport.label}`
				// );

				$('.chatSpprt').attr('href', kyubiConfig.footer.chatSupport.url);
			}
		}

		if (kyubiConfig.footer.officialGroup.willBeDisplayed) {
			if (kyubiConfig.footer.officialGroup.label) {
				chatSupportHtml += ` <li><a href="${kyubiConfig.footer.officialGroup.url}" target="_blank"><img src="images/people.svg" alt="people" width="16px" height="16px">${kyubiConfig.footer.officialGroup.label}</a></li></ul>`;

				// $('.spprtGroup').html(
				// 	`<img src="images/group.svg" alt="messenger" /> ${kyubiConfig.footer.officialGroup.label}`
				// );
				$('.spprtGroup').attr('href', kyubiConfig.footer.officialGroup.url);
			}
		}

		$('#chatSupport').html(chatSupportHtml);
	}

	if (kyubiConfig.loader.preLoader) {
		$('.loaderIcon').attr('src', kyubiConfig.loader.preLoader);
	} else {
		$('.loaderIcon').attr('src', 'images/Loader.gif');
	}

	if (kyubiConfig.logo.primary_logo) {
		$('#primary_logo').attr('src', kyubiConfig.logo.primary_logo);
	}

	if (kyubiConfig.logo.background_image) {
		$('#background_image').attr('src', kyubiConfig.logo.background_image);
	}

	if (kyubiConfig.mailTo) {
		$('#cancelMail').html(
			`To cancel your account please email us at <a href="mailto:${kyubiConfig.mailTo}">${kyubiConfig.mailTo}</a>`
		);
	} else {
		$('#cancelMail').html(`To cancel your account please contact with admin`);
	}

	$(".loginader").css("background-image", "url(" + chrome.runtime.getURL(kyubiConfig.logo.background_image) + ")");

	chrome.runtime.onMessage.addListener(
		function (message, sender, sendResponse) {
			if (message.type == "setCount") {
				$("#total_count").html("(" + message.count + ")")
				$("#count").html(message.count);
			}
			if (message.msg == "Complete") {
				//window.location.href = "../Congratulations.html";
				$("#downloadSystem").show();
				$(".modalcontent.downloadProcess").hide();
				$(".modalcontent.downloadSuccess").show();
			}
		}
	);
});
