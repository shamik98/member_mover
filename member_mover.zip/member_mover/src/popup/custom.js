var config = require('../config/config.js');
var settings = require('../../public/kyubiSettings.json');
var apiConfig = require('../config/apiConfig.json');
var services = require('../services/services.js');
var userEmail;

var debug = true;

const cr = chrome.runtime,
  cs = chrome.storage.local,
  ci = chrome.identity,
  ct = chrome.tabs;

/**
 * @desc Check the user is logged in or not, if not then redirect to login page
 */
checkLogin();

/** @desc Show User balance*/
// showBalance();

/** Login Checking */
async function checkLogin() {
  let loggedIN = await config.getUserDataFromStorage(config.mmData.level);

  if (debug) {
    console.log("loggedIN :: ", JSON.stringify(loggedIN, null, 4));
  }

  if (!loggedIN.valid || !loggedIN.mmAuthToken) location.href = 'popup.html';
  else {
    $('.userEmail').text(loggedIN.mmUsrEmail);
    userEmail = loggedIN.mmUsrEmail;
   

    // chrome.runtime.onMessage.addListener(
    //   function(response, sender, sendResponse) {        
    //     console.log("response ->",response);
    //       if (
    //         response.message == "processing"
    //       ) {
    //         chrome.runtime.sendMessage({ msg: "processing" });
    //       } else {
    //         chrome.runtime.sendMessage({ msg: "reload" });
    //       }
    //   }
    // );

    chrome.storage.local.get('msg_type', function (msg) {
      if (msg.msg_type && msg.msg_type == "processing") {
        $("#downloadSystem").show();
        $(".modalcontent.downloadProcess").show();
        $(".modalcontent.downloadSuccess").hide();
      }
    })

    //$('.planHead h2').text(loggedIN.planName);
    $('.plans').text(loggedIN.planName);
    let data = {
      userEmail: loggedIN.mmUsrEmail,
      extId: settings.extId
    }
    let url = settings.appBaseBackendUrl + apiConfig.retrieve_token;

    services.makeApiRequest('POST', data, url, {})
      .then(info => {
        console.log("info ->", info);
        chrome.storage.local.set({ token: info.userDetails[0].token });
        chrome.storage.local.set({ user_id: info.userDetails[0].id });
        let user_data = {
          token: info.userDetails[0].token
        }
        let getKeywordsUrl = settings.appBaseBackendUrl + apiConfig.get_keywords;
        services.makeApiRequest('POST', user_data, getKeywordsUrl, {})
          .then(keywords => {
            let list = "";
            if (keywords.keywordDetails !== undefined) {
              $.each(keywords.keywordDetails, function (index, value) {
                list += `<li class="posLI">
                <button type="button" class="noFill selct small posKeys" data="`+ value.keyword.toString() + `" id="` + value.id + `">` + value.name + `</button>
                  <div class="actions">
                    <button class="noFill posEdit" id="`+ value.id + `" data="` + value.keyword.toString() + `" name="` + value.name + `"><img src="images/edit.svg" /></button>
                    <button class="noFill posDelete" id="`+ value.id + `"><img src="images/delete.svg" /></button>
                  </div>
                </li>`
              });
            } else {
              list = `<li class="posLI">No saved keywords found.</li>`
            }
            $("#positiveKeywordsList").html(list);
          })
          .catch(err => {
            console.log("err :: ", JSON.stringify(err, null, 4));
          })
        let getNegKeywordsUrl = settings.appBaseBackendUrl + apiConfig.get_negative_keywords;
        services.makeApiRequest('POST', user_data, getNegKeywordsUrl, {})
          .then(negKeywords => {
            let list = "";
            if (negKeywords.keywordDetails !== undefined) {
              $.each(negKeywords.keywordDetails, function (index, value) {
                list += `<li class="negLI">
                  <button type="button" class="noFill selct small negKeys" data="`+ value.keyword.toString() + `" id="` + value.id + `">` + value.name + `</button>
                    <div class="actions">
                      <button class="noFill negEdit" id="`+ value.id + `" data="` + value.keyword.toString() + `" name="` + value.name + `"><img src="images/edit.svg" /></button>
                      <button class="noFill negDelete" id="`+ value.id + `"><img src="images/delete.svg" /></button>
                    </div>
                  </li>`
              });
            } else {
              list = `<li class="negLI">No saved keywords found.</li>`
            }
            $("#negativeKeywordsList").html(list);
          })
          .catch(err => {
            console.log("err :: ", JSON.stringify(err, null, 4));
          })
      })
      .catch(err => {
        console.log("err :: ", JSON.stringify(err, null, 4));
      })

    $('.planHead h2').text(loggedIN.planName);
    $('.balanceLoader').hide();
    $('.balanceArea').show();
  }
}

/** Log out extension */
async function logoutExt(logoutURL, email, extId) {
  try {
    return new Promise(async function (resolve, reject) {
      let loggedIN = await config.getUserDataFromStorage(config.mmData.level);

      fetch(settings.clearSubscriptionObjectURL, {
        method: 'POST', // *GET, POST, PUT, DELETE, etc.
        mode: 'cors', // no-cors, cors, *same-origin
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json',
          Authorization: 'KYUBI_' + loggedIN.mmAuthToken,
          'Access-Control-Allow-Origin': '*',
        },
        body: JSON.stringify({
          email: loggedIN.mmUsrEmail,
          extId: settings.extId,
        }), // body data type must match "Content-Type" header
      })
        .then((response) => response.json())
        .then((res) => {
          if (res.status) {
            localStorage.clear();
            $('#main').hide();
            $('#frm-login').show();
            $('#btn-logout').hide();
          }
          resolve(true);
        })
        .catch((err) => {
          resolve(false);
        });
    });
  } catch (error) { }
}

/**
 *
 * @param {String} oldPass
 * @param {String} newPass
 * @param {String} confPass
 * @desc Change Password functionality
 */
async function changePass(oldPass, newPass, confPass) {
  try {
    let loggedIN = await config.getUserDataFromStorage(config.mmData.level);
    if (loggedIN.valid && loggedIN.mmAuthToken) {
      let res = await fetch(settings.changePassURL, {
        method: 'POST',
        mode: 'cors',
        cache: 'no-cache',
        headers: {
          'Content-Type': 'application/json',
          Authorization: 'KYUBI_' + loggedIN.mmAuthToken,
        },
        redirect: 'follow',
        referrerPolicy: 'no-referrer',
        body: JSON.stringify({
          extensionId: settings.extId,
          email: loggedIN.mmUsrEmail,
          password: oldPass,
          newPassword: newPass,
          confirmNewPassword: confPass,
        }),
      });

      let jsonRes = res.json();
      return jsonRes;
    }
  } catch (error) {
    alert(error.message);
    return false;
  }
}

$(document).ready(function () {
  $('.counter').hide();

  // for onclick moremenu
  $('.moreMenuButton').click(function () {
    $(this).siblings('.menuOptions').addClass('menuActive');
  });
  $('.closeButton').click(function () {
    $(this).parent('.menuOptions').removeClass('menuActive');
  });
  // for adding active class in radio field
  $('.radioField').click(function () {
    $(this).siblings().removeClass('active');
    $(this).addClass('active');
  });

  if ($('.changePass-btn').length > 0) {
    $('.changePass-btn').click(async function () {
      $('.form-error-message').hide();
      if ($('#newPass').val() !== $('#confPass').val()) {
        $('.confPasswordErrMsg').show();
      } else {
        let info = await changePass(
          $('#oldPass').val(),
          $('#newPass').val(),
          $('#confPass').val()
        );
        if (info.status) {
          $('#changePassForm').trigger('reset');
          $('.form-success-message').text(info.message).show();
        } else {
          $('.oldPasswordErrMsg').text(info.message).show();
        }
      }
    });
  }

  /**
   * @desc Logging out the user from the extension
   */
  $('.logout-btn').click(async function (e) {
    e.preventDefault();

    await logoutExt();
    localStorage.mmAuthToken = '';
    cs.set({
      level: {
        valid: false,
        mmAuthToken: '',
        mmUsrEmail: '',
        mmBackednToken: '',
      },
      sheetURL: '',
    });

    chrome.storage.local.remove(('store'), function () {
      //console.log("Or Its clicking here");
      window.location.replace("../popup.html");
    });

    chrome.tabs.query({}, (tabs) => {
      tabs.forEach((tab) => {
        chrome.tabs.sendMessage(tab.id, { type: 'reqForCloseTab' });
      });
    });
  });

  /** back button click event */
  $('.backBtn').click(() => {
    location.href = './dashboard.html';
  });

  // $('input[type=radio][name=search_type]').change(function() {
  //   console.log("this.value ->",this.value);
  //   if (this.value == "email_phone") {
  //     $("#delay_dropdown").show()
  //   } else {
  //     $("#delay_dropdown").hide()
  //   }
  // });

  $('#email_phone').change(function () {
    if ($("#email_phone").is(':checked')) {
      $("#delay_dropdown").show();  // checked
    } else {
      $("#delay_dropdown").hide();  // unchecked
    }
  })

  $("#savePosKey").click(async function () {
    let loggedIN = await config.getUserDataFromStorage(config.mmData.level);
    let positiveKeywords = $('#positiveKeywords').val();
    if (loggedIN.planNo == 1) {
      alert("Sorry that is for a higher plan, please contact who you purchased from.")
    } else if (positiveKeywords === "" && !positiveKeywords) {
      alert("Please provide some keywords")
    } else {
      $("#savePosKeyword").show();
    }
  });
  $("#saveNegKey").click(async function () {
    let loggedIN = await config.getUserDataFromStorage(config.mmData.level);
    let negativeKeywords = $('#negativeKeywords').val();
    if (loggedIN.planNo == 1) {
      alert("Sorry that is for a higher plan, please contact who you purchased from.")
    } else if (negativeKeywords === "" && !negativeKeywords) {
      alert("Please provide some keywords")
    } else {
      $("#saveNegKeyword").show();
    }
  });

  $('#spd').click(async () => {
    let loggedIN = await config.getUserDataFromStorage(config.mmData.level);

    //let search_type = $('input[name="search_type"]:checked').val();
    let search_type = $("#email_phone").is(':checked'); // Toggle to check if user wants phone and email.
    let positiveKeywords = $('#positiveKeywords').val().split(",");
    let negativeKeywords = $('#negativeKeywords').val().split(",");

    if (loggedIN.planNo == 1 && (search_type || positiveKeywords[0] != "" || negativeKeywords[0] != "")) {
      alert("Sorry that is for a higher plan, please contact who you purchased from.")
    } else if (loggedIN.planNo >= 2 && loggedIN.planNo < 5 && search_type) {
      alert("Sorry that is for a higher plan, please contact who you purchased from.")
    } else {
      chrome.tabs.query({ currentWindow: true, active: true }, (tabs) => {
        tabs.forEach((tab) => {
          chrome.tabs.sendMessage(tab.id, { type: 'startProcedure', msg: "processing" });
        });
        //chrome.storage.local.set({ delay: $('#delay').val() });
        chrome.storage.local.set({ delay: $('#delay_time_input').attr('data-value') });
        chrome.storage.local.set({ search_type: search_type });
        chrome.storage.local.set({ positiveKeywords: positiveKeywords });
        chrome.storage.local.set({ negativeKeywords: negativeKeywords });
        chrome.runtime.sendMessage({ msg: "processing" });
        //location.href = './processingData.html';
        $("#downloadSystem").show();
        $(".modalcontent.downloadProcess").show();
        $(".modalcontent.downloadSuccess").hide();
      });
    }
  });

  $('#sad').click(() => {
    chrome.tabs.query({}, (tabs) => {
      console.log("tabs====", tabs);
      tabs.forEach((tab) => {
        console.log("TabId ----------- ", tab.Id);
        chrome.tabs.sendMessage(tab.id, { type: 'stopProcedure', msg: 'Complete' });
      });
      //location.href = './Congratulations.html';
      $(".modalcontent.downloadProcess").hide();
      $(".modalcontent.downloadSuccess").show();
    });
  });

  $('#savePosBtn').click(() => {
    chrome.storage.local.get('token', function (data) {
      let token = data.token
      let posKeywordName = $("#posKeywordName").val();
      let positiveKeywords = $('#positiveKeywords').val().split(",");
      if (posKeywordName === "") {
        $("#titleErr").show();
      } else {
        let data = {
          name: posKeywordName,
          keyword: positiveKeywords,
          token: token
        }
        let url = settings.appBaseBackendUrl + apiConfig.save_keywords;
        services.makeApiRequest('POST', data, url, {})
          .then(details => {
            console.log("details ->", details);
            if (details.status) {
              let list = "";
              $.each(details.keywords, function (index, value) {
                list += `<li class="posLI">
                <button type="button" class="noFill selct small posKeys" data="`+ value.keyword.toString() + `" id="` + value.id + `">` + value.name + `</button>
                  <div class="actions">
                    <button class="noFill posEdit" id="`+ value.id + `" data="` + value.keyword.toString() + `" name="` + value.name + `"><img src="images/edit.svg" /></button>
                    <button class="noFill posDelete" id="`+ value.id + `"><img src="images/delete.svg" /></button>
                  </div>
                </li>`
              });
              $("#positiveKeywordsList").html(list);
              alert("Keyword saved successfully.")
              $("#savePosKeyword").hide();
            } else {
              alert(details.message);
            }

          })
          .catch(err => {
            console.log("err :: ", JSON.stringify(err, null, 4));
            alert("Error while saving keywords. Please try again");
          })
      }
    })
  })

  $("#primary_logo").click(function () {
    goHome();
  });

  $('#gh').click(() => {
    goHome();
  });

  function goHome() {
    chrome.runtime.sendMessage({ msg: "reload" });
    chrome.runtime.sendMessage({ msg: "clearBadge" });
    setTimeout(function () {
      window.location.href = "../dashboard.html";
    }, 200);
  }

  $('#cancelEmail').text(settings.mailTo);

  $('#tv').attr("href", settings.trainingVideos);

  $('#editSavePosBtn').click(() => {
    let editPositiveKeywords = $("#editPositiveKeywords").val();
    let hiddenEditPositiveKeywords = $("#hiddenEditPositiveKeywords").val();
    let editPosKeywordName = $("#editPosKeywordName").val();
    let hiddenEditPosKeywordName = $("#hiddenEditPosKeywordName").val();
    let hiddenEditPosKeywordId = $("#hiddenEditPosKeywordId").val();

    $("#editPosKey").hide();
    $("#editTitleErr").hide();

    if (editPositiveKeywords == "") {
      $("#editPosKey").show();
    } else if (editPosKeywordName == "") {
      $("#editTitleErr").show();
    } else if (editPositiveKeywords == hiddenEditPositiveKeywords && editPosKeywordName == hiddenEditPosKeywordName) {
      alert("Nothing to update.")
    } else {
      chrome.storage.local.get('token', function (key) {
        let token = key.token
        let posKeywordName = $('#editPositiveKeywords').val().split(",");
        let data = {
          name: editPosKeywordName,
          old_name: hiddenEditPosKeywordName,
          keyword: posKeywordName,
          id: hiddenEditPosKeywordId,
          token: token
        }
        let url = settings.appBaseBackendUrl + apiConfig.update_keywords;
        services.makeApiRequest('POST', data, url, {})
          .then(details => {
            if (details.status) {
              alert("Keyword updated successfully.")
              $("#keywordlist").trigger("click");
              $("#editKeyword").hide();
              checkLogin();
            } else {
              alert(details.message);
            }
          })
          .catch(err => {
            console.log("err :: ", JSON.stringify(err, null, 4));
            alert("Error while saving keywords. Please try again");
          })
      })
    }
  });

  $("#confirmDelete").on("click", () => {
    let row_id = $("#confirmDelete").attr('row_id');
    let data = {
      id: row_id
    }
    let url = settings.appBaseBackendUrl + apiConfig.delete_keywords;
    services.makeApiRequest('POST', data, url, {})
      .then(details => {
        if (details.status) {
          alert("Keyword deleted successfully.")
          $("#keywordlist").trigger("click");
          $("#deleteKeyword").hide();
          checkLogin();
        } else {
          alert(details.message);
        }
      })
      .catch(err => {
        console.log("err :: ", JSON.stringify(err, null, 4));
        alert("Error while saving keywords. Please try again");
      })
  });

  $('#saveNegBtn').click(() => {
    chrome.storage.local.get('token', function (data) {
      let token = data.token
      let negKeywordName = $("#negKeywordName").val();
      let negativeKeywords = $('#negativeKeywords').val().split(",");
      if (negKeywordName === "") {
        $("#titleErr").show();
      } else {
        let data = {
          name: negKeywordName,
          keyword: negativeKeywords,
          token: token
        }
        let url = settings.appBaseBackendUrl + apiConfig.save_negative_keywords;
        services.makeApiRequest('POST', data, url, {})
          .then(details => {
            if (details.status) {
              let list = "";
              $.each(details.keywords, function (index, value) {
                list += `<li class="negLI">
                <button type="button" class="noFill selct small negKeys" data="`+ value.keyword.toString() + `" id="` + value.id + `">` + value.name + `</button>
                  <div class="actions">
                    <button class="noFill negEdit" id="`+ value.id + `" data="` + value.keyword.toString() + `" name="` + value.name + `"><img src="images/edit.svg" /></button>
                    <button class="noFill negDelete" id="`+ value.id + `"><img src="images/delete.svg" /></button>
                  </div>
                </li>`
              });
              $("#negativeKeywordsList").html(list);
              alert("Keyword saved successfully.")
              $("#saveNegKeyword").hide();
            } else {
              alert(details.message);
            }

          })
          .catch(err => {
            console.log("err :: ", JSON.stringify(err, null, 4));
            alert("Error while saving keywords. Please try again");
          })
      }
    })
  })

  $('#editSaveNegBtn').click(() => {
    let editNegativeKeywords = $("#editNegativeKeywords").val();
    let hiddenEditNegativeKeywords = $("#hiddenEditNegativeKeywords").val();
    let editNegKeywordName = $("#editNegKeywordName").val();
    let hiddenEditNegKeywordName = $("#hiddenEditNegKeywordName").val();
    let hiddenEditNegKeywordId = $("#hiddenEditNegKeywordId").val();

    $("#editNegKey").hide();
    $("#editNegTitleErr").hide();

    if (editNegativeKeywords == "") {
      $("#editNegKey").show();
    } else if (editNegKeywordName == "") {
      $("#editNegTitleErr").show();
    } else if (editNegativeKeywords == hiddenEditNegativeKeywords && editNegKeywordName == hiddenEditNegKeywordName) {
      alert("Nothing to update.")
    } else {
      chrome.storage.local.get('token', function (key) {
        let token = key.token
        let NegKeywordName = $('#editNegativeKeywords').val().split(",");
        let data = {
          name: editNegKeywordName,
          old_name: hiddenEditNegKeywordName,
          keyword: NegKeywordName,
          id: hiddenEditNegKeywordId,
          token: token
        }
        let url = settings.appBaseBackendUrl + apiConfig.update_negative_keywords;
        services.makeApiRequest('POST', data, url, {})
          .then(details => {
            if (details.status) {
              alert("Keyword updated successfully.")
              $("#negKeywordlist").trigger("click");
              $("#editNegKeyword").hide();
              checkLogin();
            } else {
              alert(details.message);
            }
          })
          .catch(err => {
            console.log("err :: ", JSON.stringify(err, null, 4));
            alert("Error while saving keywords. Please try again");
          })
      })
    }
  });

  $("#negConfirmDelete").on("click", () => {
    let row_id = $("#negConfirmDelete").attr('row_id');
    let data = {
      id: row_id
    }
    let url = settings.appBaseBackendUrl + apiConfig.delete_negative_keywords;
    services.makeApiRequest('POST', data, url, {})
      .then(details => {
        if (details.status) {
          alert("Keyword deleted successfully.")
          $("#negKeywordlist").trigger("click");
          $("#deleteNegKeyword").hide();
          checkLogin();
        } else {
          alert(details.message);
        }
      })
      .catch(err => {
        console.log("err :: ", JSON.stringify(err, null, 4));
        alert("Error while saving keywords. Please try again");
      })
  });
});


$(document).on("click", ".posKeys", function () {
  $('#positiveKeywords').tagsinput('removeAll');
  let arr = $(this).attr("data").split(",");
  arr.forEach(function (value, index) {
    $('#positiveKeywords').tagsinput('add', value);
  });
})

$(document).on("click", ".posEdit", function () {
  $('#editPositiveKeywords').tagsinput('removeAll');
  let arr = $(this).attr("data").split(",");
  arr.forEach(function (value, index) {
    $('#editPositiveKeywords').tagsinput('add', value);
  });
  $("#hiddenEditPositiveKeywords").val($(this).attr("data"))
  $("#editPosKeywordName").val($(this).attr("name"))
  $("#hiddenEditPosKeywordName").val($(this).attr("name"))
  $("#hiddenEditPosKeywordId").val($(this).attr("id"))
  $("#editKeyword").show();
})

$(document).on("click", ".posDelete", function () {
  $("#confirmDelete").attr("row_id", $(this).attr("id"));
  $("#deleteKeyword").show();
})

$(document).on("click", ".negKeys", function () {
  $('#negativeKeywords').tagsinput('removeAll');
  let arr = $(this).attr("data").split(",");
  arr.forEach(function (value, index) {
    $('#negativeKeywords').tagsinput('add', value);
  });
})

$(document).on("click", ".negEdit", function () {
  $('#editNegativeKeywords').tagsinput('removeAll');
  let arr = $(this).attr("data").split(",");
  arr.forEach(function (value, index) {
    $('#editNegativeKeywords').tagsinput('add', value);
  });
  $("#hiddenEditNegativeKeywords").val($(this).attr("data"))
  $("#editNegKeywordName").val($(this).attr("name"))
  $("#hiddenEditNegKeywordName").val($(this).attr("name"))
  $("#hiddenEditNegKeywordId").val($(this).attr("id"))
  $("#editNegKeyword").show();
})

$(document).on("click", ".negDelete", function () {
  $("#negConfirmDelete").attr("row_id", $(this).attr("id"));
  $("#deleteNegKeyword").show();
})