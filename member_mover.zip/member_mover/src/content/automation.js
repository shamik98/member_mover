/** const config = require('../config/config');
var settings = require('../../public/kyubiSettings.json');
const { toastMessage } = require('../config/config');
const { getJSDocTags } = require('typescript');
let services = require('../services/apiServices'); **/

import config from '../config/config';
import * as settings from "../../public/kyubiSettings.json";
import apiServices from '../services/apiServices';

const cr = chrome.runtime;
const cs = chrome.storage.local;

$(document).ready(async function () {
	let groupId = '',
		membersInfo = [],
		TotalCount = 0,
		stopped = false,
		downloaded = false,
		processing = false,
		customTimeOut;

	let memInfo = {};

	let loggedIN = await config.getUserDataFromStorage(config.mmData.level);

	chrome.storage.local.set({ membersInfo: membersInfo });

	cr.onMessage.addListener((req, sender, sendResponse) => {
		switch (req.type) {
			case 'startProcedure':
				processing = true;
				cr.sendMessage({ msg: 'processing' });
				cs.set({ msg_type: 'processing' });
				fetchGroupMembersInfo();
				break;
			case 'stopProcedure':
				// console.log("stopProcedure ----------------------- ", sender)
				cs.set({ msg_type: '' });
				stopped = true;
				stopFetchingMembers();
				break;
		}
	});

	/**
	 * This method will look for members and fetch their informations
	 */

	function fetchGroupMembersInfo() {
		groupId = getGroupID();
		cs.get(["DTSG", "USER_ID"], ({ DTSG, USER_ID }) => {
			membersInfo = [];
			TotalCount = 0;
			pickData(groupId, DTSG, USER_ID);
		});
	}

	chrome.runtime.sendMessage({ msg: "get_tab_id" });

	/** Get Group Id  */
	function getGroupID() {
		let groupIdContainerString = document.querySelector('[href*="/user/"]').href;
		let groupIdContainerStringArr = groupIdContainerString.split('/');
		let groupId =
			groupIdContainerStringArr[groupIdContainerStringArr.indexOf('groups') + 1];
		return groupId;
	}

	function pickData(groupId, DTSG, USER_ID, cursor = null) {

		chrome.storage.local.set({ groupId: groupId });
		let delay = '',
			positive_keywords = '',
			negative_keywords = '';

		chrome.storage.local.get('delay', function (result) {
			delay = (result.delay * 60000) + ((Math.floor(Math.random() * (11 - 1)) + 1) * 1000);
		})

		cs.get('positiveKeywords', function (result) {
			positive_keywords = result.positiveKeywords.map(v => v.toLowerCase())
		})

		cs.get('negativeKeywords', function (result) {
			negative_keywords = result.negativeKeywords.map(v => v.toLowerCase())
		})

		let memberDetails = apiServices.fetchGroupMembers(groupId, cursor, USER_ID, DTSG, (memberDetails) => {
			chrome.runtime.sendMessage({
				message: "fetch_member",
				delayInterval: delay,
				USER_ID: USER_ID,
				DTSG: DTSG,
				members: JSON.parse(memberDetails).data.node.new_members.edges,
				memberPageInfo: JSON.parse(memberDetails).data.node.new_members.page_info,
				positive_keywords: positive_keywords,
				negative_keywords: negative_keywords
			});
		});
	}

	function fetchMembers(delayInterval, USER_ID, DTSG, members, memberPageInfo, positive_keywords, negative_keywords) {
		let count = 0;
		downloaded = false;
		chrome.storage.local.get('search_type', function (result) {

			//if (loggedIN.planNo == 5 && result.search_type == "email_phone") {
			if (loggedIN.planNo == 5 && result.search_type) {

				members.forEach((member, i) => {
					// prepare members data
					let fb_id = "";
					if (member.node.invitee_profile !== undefined) {
						fb_id = member.node.invitee_profile.id;
					}else{
						fb_id = member.node.id;
					}

					let memInfo = {
						email: "N/A",
						fb_id: fb_id,
						fb_profile: "https://www.facebook.com/" + fb_id,
						name: member.node.name,
						bio_text: member.node.bio_text ? member.node.bio_text.text : "N/A",
						phone: "N/A"
					}

					setTimeout(function () {
						let member_details_length = members.length;
						let member_details_page_info = memberPageInfo;

						count++;
						TotalCount++;

						if (processing) {
							if (member.node.invitee_profile !== undefined && member.node.invitee_profile.bio_text !== null) {
								cr.sendMessage({ msg: "open_tab", member_info: memInfo, USER_ID: USER_ID, DTSG: DTSG, member_details_length: member_details_length, member_details_page_info: member_details_page_info, count: count, TotalCount: TotalCount, desc: member.node.invitee_profile.bio_text.text });
							} else if (member.node.bio_text && member.node.bio_text.text !== undefined) {
								cr.sendMessage({ msg: "open_tab", member_info: memInfo, USER_ID: USER_ID, DTSG: DTSG, member_details_length: member_details_length, member_details_page_info: member_details_page_info, count: count, TotalCount: TotalCount, desc: member.node.bio_text.text });
							} else {
								cr.sendMessage({ msg: "open_tab", member_info: memInfo, USER_ID: USER_ID, DTSG: DTSG, member_details_length: member_details_length, member_details_page_info: member_details_page_info, count: count, TotalCount: TotalCount, desc: null });
							}
						}
					}, i * parseInt(delayInterval));
				})
			} else if (loggedIN.planNo >= 2 && (negative_keywords[0] != "" || positive_keywords[0] != "")) {
				members.forEach((member, i) => {
					// prepare members data
					let fb_id = "";
					if (member.node.invitee_profile !== undefined) {
						fb_id = member.node.invitee_profile.id;
					}else{
						fb_id = member.node.id;
					}
					let memInfo = {
						fb_id: fb_id,
						fb_profile: "https://www.facebook.com/" + fb_id,
						name: member.node.name,
						bio_text: member.node.bio_text ? member.node.bio_text.text : "N/A",
					}

					let desc = "";

					if (member.node.invitee_profile !== undefined) {
						desc = member.node.invitee_profile.bio_text ? member.node.invitee_profile.bio_text.text.toLowerCase() : "";
					}else{
						desc = member.node.bio_text ? member.node.bio_text.text.toLowerCase() : "";
					}

					let negativeKeywordsFilter = filterProfileWithKeywords(desc, negative_keywords);
					let positiveKeywordsFilter = filterProfileWithKeywords(desc, positive_keywords);

					if (negative_keywords[0] != "" && desc) {

						if (!negativeKeywordsFilter.status && positive_keywords[0] != "") {
							if (positiveKeywordsFilter.status) {
								memInfo.keyword = positiveKeywordsFilter.keyword;
								membersToExport(memInfo);
							}
						} else if (!negativeKeywordsFilter.status && !positive_keywords[0] != "") {
							memInfo.keyword = positiveKeywordsFilter.keyword;
							membersToExport(memInfo);
						}

					} else if (positive_keywords[0] != "" && desc) {
						if (positiveKeywordsFilter.status) {
							memInfo.keyword = positiveKeywordsFilter.keyword;
							membersToExport(memInfo);
						}
					}

					count++;

					let member_details_page_info = memberPageInfo;

					if (count == members.length) {
						playWithData(member_details_page_info);
					}

				})
			} else {
				members.forEach((member, i) => {
					// prepare members data
					let fb_id = "";
					if (member.node.invitee_profile !== undefined) {
						fb_id = member.node.invitee_profile.id;
					}else{
						fb_id = member.node.id;
					}
					let memInfo = {
						fb_id: fb_id,
						fb_profile: "https://www.facebook.com/" + fb_id,
						name: member.node.name,
						bio_text: member.node.bio_text ? member.node.bio_text.text : "N/A",
					}

					membersToExport(memInfo);

					count++;

					let member_details_page_info = memberPageInfo;

					if (count == members.length) {
						playWithData(member_details_page_info);
					}
				});
			}
		})
	}

	function membersToExport(memInfo) {
		membersInfo.push(memInfo);
		TotalCount++;
		cr.sendMessage({ msg: "set_count", count: TotalCount });
	}

	function filterProfileWithKeywords(desc, keywordsArr) {
		let regexFromArray = new RegExp(keywordsArr.join("|"), "gi");
		let position = null;
		if (desc) {
			position = desc.match(regexFromArray); // can give multiple keywords sperating by '|'
		}
		return position !== null ? { status: true, keyword: position[0] } : { status: false };
	}

	chrome.runtime.onMessage.addListener(async (req, sender, sendResponse) => {

		let sender_id = req.sender_tab_id;
		chrome.storage.local.get("all_member_details", function (obj) {
			// console.log("all_member_details >>> 247", obj.all_member_details);
			if (sender_id !== undefined) {
				let positive_keywords = '',
					negative_keywords = '';

				cs.get('positiveKeywords', function (result) {
					positive_keywords = result.positiveKeywords
				})

				cs.get('negativeKeywords', function (result) {
					negative_keywords = result.negativeKeywords
				})
				let tab_member_details = obj.all_member_details.member_info;

				let memberContactDetails = apiServices.fetchGroupMembersDetails(obj.all_member_details.USER_ID, tab_member_details.fb_id, null, obj.all_member_details.DTSG, (data) => {

					let phone = data.data.user.about_app_sections.nodes[0].activeCollections.nodes[0].style_renderer.profile_field_sections ? data.data.user.about_app_sections.nodes[0].activeCollections.nodes[0].style_renderer.profile_field_sections[0].profile_fields.nodes.forEach((memberDetails, i) => {
						if (memberDetails.field_type === 'other_phone') {
							tab_member_details.phone = memberDetails.title.text;
						} else {
							tab_member_details.phone = 'N/A';
						}
					}) : tab_member_details.phone = 'N/A';

					let collectionToken = "";

					let tokenId = data.data.user.about_app_sections.nodes[0].all_collections.nodes.forEach((token, i) => {
						if (token.name == "Contact and basic info") {
							collectionToken = token.id;
						}
					})

					// console.log("tab_member_details >>> 247", tab_member_details);
					// console.log("collectionToken >>> 247", collectionToken);

					let memberEmail = apiServices.fetchGroupMembersDetails(obj.all_member_details.USER_ID, tab_member_details.fb_id, collectionToken, obj.all_member_details.DTSG, (memberEmail) => {
						let email = memberEmail.data.user.about_app_sections.nodes[0].activeCollections.nodes[0].style_renderer.profile_field_sections[0] ? memberEmail.data.user.about_app_sections.nodes[0].activeCollections.nodes[0].style_renderer.profile_field_sections[0].profile_fields.nodes.forEach((userEmail, i) => {
							if (userEmail.field_type === 'email') {
								tab_member_details.email = userEmail.title.text;
							} else {
								tab_member_details.email = 'N/A';
							}
						}) : tab_member_details.email = 'N/A';

						let desc = obj.all_member_details.desc ? obj.all_member_details.desc.toLowerCase() : "";
						let negativeKeywordsFilter = filterProfileWithKeywords(desc, negative_keywords);
						let positiveKeywordsFilter = filterProfileWithKeywords(desc, positive_keywords);

						// console.log("tab_member_details >>> 295   llll", tab_member_details);

						if (negative_keywords[0] != "" || positive_keywords[0] != "") {
							if (negative_keywords[0] != "" && desc) {
								if (!negativeKeywordsFilter.status && positive_keywords[0] != "") {
									if (positiveKeywordsFilter.status) {
										tab_member_details.keyword = positiveKeywordsFilter.keyword;
										membersInfo.push(tab_member_details);
										// membersToExport(tab_member_details); // Added By Ankur
									}
								} else if (!negativeKeywordsFilter.status && !positive_keywords[0] != "") {
									tab_member_details.keyword = positiveKeywordsFilter.keyword;
									membersInfo.push(tab_member_details);
									// membersToExport(tab_member_details); // Added By Ankur
								}

							} else if (positive_keywords[0] != "" && desc) {
								if (positiveKeywordsFilter.status) {
									tab_member_details.keyword = positiveKeywordsFilter.keyword;
									membersInfo.push(tab_member_details);
									// membersToExport(tab_member_details); // Added By Ankur
								}
							}
						}
						else {
							membersInfo.push(tab_member_details);
							// membersToExport(tab_member_details); // Added By Ankur
						}

						// console.log("membersInfo >>>> 320 ", membersInfo)

						if (obj.all_member_details.count == obj.all_member_details.member_details_length) {
							const exportData = new Promise((resolve, reject) => {
								//chrome.runtime.sendMessage({message :"receive_from_page",update_msg : membersInfo, sender_id : null, close_after_save : sender_id});
								chrome.runtime.sendMessage({ message: "receive_from_page", update_msg: membersInfo, sender_id: sender_id });
								resolve("success")
							})
							exportData.then(msg => {
								if (msg == "success") {
									playWithData(obj.all_member_details.member_details_page_info);
								}
							})
						} else {
							chrome.runtime.sendMessage({ message: "receive_from_page", update_msg: membersInfo, sender_id: sender_id });
						}
					})
				});
			}
		});
		return true;
	})

	function playWithData(page_info) {
		if (page_info.has_next_page == true && !stopped) {
			customTimeOut = setTimeout(function () {
				cs.get(["DTSG", "USER_ID", "groupId"], ({ DTSG, USER_ID, groupId }) => {
					pickData(groupId, DTSG, USER_ID, page_info.end_cursor);
				});
			}, 5000);
		} else if (!downloaded) {
			chrome.storage.local.get('search_type', function (result) {
				if (loggedIN.planNo == 1 || (loggedIN.planNo >= 2 && result.search_type == "none")) {
					exportCsv();
				} else {
					chrome.runtime.sendMessage({ message: "retriveTheDataFromLocalStorage" });
				}
				cr.sendMessage({ msg: "Complete" });
			})
		}
	}

	chrome.runtime.onMessage.addListener((req, sender, sendResponse) => {
		if (req.message == 'callFunction') {
			exportCsv(req.data);
		}
		if (req.message == 'getMemberDetails') {
			fetchMembers(req.delayInterval, req.USER_ID, req.DTSG, req.members, req.memberPageInfo, req.positive_keywords, req.negative_keywords);
		}
	});

	function exportCsv(membersDetails = null) {
		// console.log("membersDetails=====", JSON.stringify(membersDetails));
		cs.set({ msg_type: '' });
		clearTimeout(customTimeOut);
		let jsonObject = "";
		const jsonData = new Promise((resolve, reject) => {
			chrome.storage.local.get('search_type', function (result) {
				if (loggedIN.planNo == 1 || (loggedIN.planNo >= 2 && result.search_type === false)) {
					cs.get('positiveKeywords', function (keyword) {
						if (keyword.positiveKeywords[0] != "") {
							membersInfo.unshift(["Facebook ID", "Facebook Profile Link", "Name", "Bio Text", "Keyword"]);
						} else {
							membersInfo.unshift(["Facebook ID", "Facebook Profile Link", "Name", "Bio Text"]);
						}
						jsonObject = JSON.stringify(membersInfo);
						// console.log("jsonObject========= 1", jsonObject)
						resolve("success")
					})
				} else {
					// "bio_text":"",
					// "email":"N/A",
					// "fb_id":"100017206140881",
					// "fb_profile":"https://www.facebook.com/100017206140881",
					// "name":"Bishal Mistri",
					// "phone":"N/A"
					cs.get('positiveKeywords', function (keyword) {
						if (keyword.positiveKeywords[0] != "") {
							// membersDetails.unshift(["Email", "Facebook ID", "Facebook Profile Link", "Keyword", "Name", "Bio Text", "Phone"]);
							membersDetails.unshift(["Bio Text", "Email", "Facebook ID", "Facebook Profile Link", "Keyword", "Name", "Phone"]);
						} else {
							// membersDetails.unshift(["Email", "Facebook ID", "Facebook Profile Link", "Name", "Bio Text", "Phone"]);
							membersDetails.unshift(["Bio Text", "Email", "Facebook ID", "Facebook Profile Link", "Name", "Phone"]);
						}
						jsonObject = JSON.stringify(membersDetails);
						// console.log("jsonObject========= 2", jsonObject)
						resolve("success")
					})
				}
			})
		})
		jsonData.then(msg => {
			if (msg == "success") {
				// console.log("jsonData ===== ", jsonData)
				var csv = ConvertToCSV(jsonObject);

				let currentUrl = window.location.href;
				let groupName = currentUrl.split('?')[0].split('/').slice(-2)[0];


				let blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
				if (navigator.msSaveBlob) {
					// IE 10+
					navigator.msSaveBlob(blob, groupName);
				} else {
					let link = document.createElement("a");
					if (link.download !== undefined) {
						// feature detection
						// Browsers that support HTML5 download attribute
						let url = URL.createObjectURL(blob);
						link.setAttribute("href", url);
						link.setAttribute("download", groupName + '.csv');
						link.style.visibility = "hidden";
						document.body.appendChild(link);
						link.click();
						document.body.removeChild(link);
					}
				}
				downloaded = true;
				processing = false;
			}
		})
	}

	function ConvertToCSV(objArray) {

		var array = typeof objArray != 'object' ? JSON.parse(objArray) : objArray;
		var str = '';

		for (let i = 0; i < array.length; i++) {
			if (array[i]) {
				let line = "";
				for (let index in array[i]) {
					if (line !== "") line += ",";
					line += array[i][index];
				}
				str += line + "\r\n";
			}
		}
		return str;

	}

	/**
	 * This method will stop fetching informations and will download the data
	 */

	function stopFetchingMembers() {
		clearTimeout(customTimeOut);
		chrome.storage.local.get('search_type', function (result) {
			if (loggedIN.planNo == 1 || (loggedIN.planNo >= 2 && result.search_type == "none")) {
				// console.log("kkkkkkkkkkkkkkkkkkkkkkkkkkkkkk463", result);
				exportCsv();
			} else {
				// console.log("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhh466", result);
				chrome.runtime.sendMessage({ message: "exportMembers" });
			}
			cr.sendMessage({ msg: "Complete" });
		})
	}

});

