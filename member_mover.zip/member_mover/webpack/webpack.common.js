const webpack = require('webpack');
const path = require('path');
const CopyPlugin = require('copy-webpack-plugin');
const srcDir = '../src/';

module.exports = {
	entry: {
		'js/background': path.join(__dirname, srcDir + 'background/background.js'),
		'js/automation': path.join(__dirname, srcDir + 'content/automation.js'),
		'js/popup': path.join(__dirname, srcDir + 'popup/popup.js'),
		'js/common': path.join(__dirname, srcDir + 'popup/common.js'),
		'js/custom': path.join(__dirname, srcDir + 'popup/custom.js'),
		'js/config': path.join(__dirname, srcDir + 'config/config.js'),
		'js/apiConfig': path.join(__dirname, srcDir + 'config/apiConfig.json'),
		'js/apiServices': path.join(__dirname, srcDir + 'services/apiServices.js'),
		'background-wrapper': path.join(
			__dirname,
			srcDir + 'background/background-wrapper.js'
		),
	},
	output: {
		path: path.join(__dirname, '../dist'),
		filename: '[name].bundle.js',
	},
	optimization: {
		splitChunks: {
			name: 'vendor',
			chunks: 'initial',
		},
	},
	module: {
		rules: [
			{
				test: /\.tsx?$/,
				use: 'ts-loader',
				exclude: /node_modules/,
			},
		],
	},
	performance: {
		maxEntrypointSize: 512000,
		maxAssetSize: 512000,
	},
	resolve: {
		extensions: ['.ts', '.tsx', '.js'],
	},
	plugins: [
        // exclude locale files in moment
        new webpack.IgnorePlugin({
            resourceRegExp: /^\.\/locale$/,
            contextRegExp: /moment$/,
        }),
        new CopyPlugin({
            patterns: [
                {
                    from: '.',
                    to: '../dist/',
                    context: 'public'
                }
            ]
        }),
    ]
};
