jQuery(document).ready(function ($) {

  $(".menuClosed").click(function () {
    $(".subMenu").addClass("show");
    $(".menuClosed").addClass("hide");
    $(".menuOpened").addClass("show");
  });

  $(".menuOpened").click(function () {
    $(".subMenu").removeClass("show");
    $(".menuClosed").removeClass("hide");
    $(".menuOpened").removeClass("show");
  });

  $("#phoneEmailChecking").click(function () {
    //console.log($(this).children('input').prop( "checked"));
    if ($(this).children('input').prop('checked') === false) {
      $(this).children('input').prop("checked", true);
      $("#phoneEmailBox").removeClass("inactive");
    } else {
      $(this).children('input').prop("checked", false);
      $("#phoneEmailBox").addClass("inactive");
    }
  });

  $("#keywordlist").click(function () {
    $("#keywordsSuggesion").toggleClass("show");
    $(this).toggleClass("rotate")
  })

  $("#negKeywordlist").click(function () {
    $("#negKeywordsSuggesion").toggleClass("show");
    $(this).toggleClass("rotate")
  })

  $("#keywordlistCountry").click(function () {
    $(this).toggleClass("rotate");
    $("#keywordsSuggesionTier").toggleClass("show");
  })

  $(".delayValue").click(function () {
    $("#delay_time_input").attr('data-value', $(this).attr('data-value'))
    $("#delay_time_input").val($(this).html())
    $("#keywordlistCountry").toggleClass("rotate");
    $("#keywordsSuggesionTier").toggleClass("show");
  })

  $(".cross").click(function () {
    $(this).parent().parent(".modalOuter").hide();
  });
  $(".modalOuter:not(#downloadSystem)").click(function () {
    $(".modalOuter").hide();
  });
  $(".modalcontent").click(function (e) {
    e.stopPropagation();
  });


  $("#deleteBtn").on("click", function () {
    $("#deleteKeyword").show();
  });
  $("#cancelDelete").on("click", function () {
    $("#deleteKeyword").hide();
  });
  $("#negCancelDelete").on("click", function () {
    $("#deleteNegKeyword").hide();
  });

  $("#corfirmDownload").on("click", function (e) {
    $("#downloadSystem").hide();
  });

  // textAreaControler();
  $(".minusKeyword").click(function () {
    $(this).parent().hide();
  });
});
